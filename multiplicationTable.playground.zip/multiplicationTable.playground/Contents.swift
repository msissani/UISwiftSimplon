import UIKit

var str = "Hello, TABLE DE MULTIPLICATION \r"

print(str)

for operator1 in 1...10 {
    for operator2 in 0...10 {
        print("\(operator1) x \(operator2) = \(operator1*operator2)",separator: "", terminator: "\t")
    }
    print("\r")
}



func calcul(number1: Int, and number2: Int) -> (Int, Int) {
    return (number1+number2,number1*number2)
}

print(calcul(number1: 3, and: 4))
