import UIKit

struct Result {
    var destination: String
    var themes: String // Dans ce cas "Thème"
    var budget: Int // Exemple "Budget"
    var transport: String // Transport
    var matching: Int
    var addFavoris: Bool
    var thumbnail: String
}



enum Preferences {
    case budget
    case theme
    case destination
    case transport
    case logement
    case date
    case sécurité
    case durée
}


var resultat1 = Result(destination: "Destination1", themes: "Thème1", budget: 750, transport: "Train", matching: 70, addFavoris: false, thumbnail: "image1")
var resultat2 = Result(destination: "Destination2", themes: "Thème1", budget: 1_000, transport: "Bus", matching: 17, addFavoris: true, thumbnail: "image2")



var resultList: [Result] = [resultat1,resultat2]

for resultrow in resultList {print(resultrow)}





