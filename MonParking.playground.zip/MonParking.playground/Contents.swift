import UIKit


let prixBien: Double = 12000.0
let prixLocation: Double = 90.0
let charges: Double = 37.0 * 4
var taxeFonciere: Double = 0.0

var rendementBrut: Double = 0.0

var rendementLocatifNet: Double = 0.0

var rendementAprèsImpot: Double = 0.0

var locationBrute: Double = prixLocation * 12

var locationNet: Double = locationBrute-charges

// TAXE FONCIERE
var locationNetImpot: Double = locationNet - (locationNet * 0.172) - (locationNet * 0.14)

/*print("ENTRER LE PRIX MENSUEL DE VOTRE LOCATION DE PARKING:")


if let input = readLine()
{
print("\(input)")
    if let prixLocation = Double(input){
        print("Votre location est de \(prixLocation)")
    } else{
        print("ERROR")
    }
 
}
*/


print("Ma location est de \(String(format:"%.2f",prixLocation)) par mois soit \(locationBrute) par an")

print("Mes charges sont de \(String(format:"%.2f",charges)) par an")

print("Mon rendement brut est de \((locationBrute/prixBien)*100) % soit \(locationBrute) Euros par an")

print("Mon rendement locatif net est de \(String(format:"%.2f",(locationNet/prixBien)*100)) % soit \(locationNet) par an ")

print("Mon rendement locatif net IMPOTS est de \(String(format:"%.2f",(locationNetImpot/prixBien)*100)) % soit une valeur de \(locationNetImpot) Euros par an")


