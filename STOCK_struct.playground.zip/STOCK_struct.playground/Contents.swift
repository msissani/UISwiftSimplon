import UIKit

struct Action {
    let name: String
    let code: String
    var value: Double
    var variation: Double
    var volume: String
}


var appleAction = Action(name: "Apple", code: "AAPL", value: 160.00, variation: 1.45, volume: "4B")
var rennerAction = Action(name: "Renner", code: "LREN3", value: 32.01, variation: -0.77, volume: "200M")
var bmwAction = Action(name: "BMW AG", code: "BMW", value: 88.35, variation: 0.0, volume: "327M")


var actions:[Action] = [appleAction, rennerAction, bmwAction]
actions.append(Action(name: "Sintex", code: "SINTEX", value: 26.95, variation: 1.35, volume: "2M"))


print("""
Stock Options 📉
---------------------------
""")


for action in actions{
    var arrow: String
    if(action.variation < 0){
        arrow = "↓"
    } else if (action.variation > 0){
        arrow = "↑"
    } else {
        arrow = "="
    }
    print("\(action.code) \t \(action.value)  \(arrow)   \(action.variation)%")
    //print("\r")
}



