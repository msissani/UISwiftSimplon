import UIKit

var str = "Hello, playground"

let names = ["Jose", "Cathy", "Winston"]
let lastnames = ["Dupont", "Richard", "Panzani"]

for name in names {
    for lastname in lastnames {
        print("Mon nom est \(name) et prénom \(lastname.uppercased())")
        break
    }
    
}
