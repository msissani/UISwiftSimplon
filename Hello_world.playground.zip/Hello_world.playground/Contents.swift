import UIKit

var str😃 = "😃"
print("Hello '\(str😃)', playground ")

print("Aicha aicha ecoute moi")
print("Aicha t'en vas pas")

