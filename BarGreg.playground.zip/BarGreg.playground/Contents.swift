import UIKit

var str = "Hello, playground"

var nachosPrice: Double = 7.50
var beerPrice: Double = 5.50
var nachosAmount: Int = 3
var beerAmount: Int = 7

var costBeer = Double(beerAmount)*beerPrice
var costNachos = Double(nachosAmount)*nachosPrice

var totalBeerNachos = costBeer + costNachos

print("""
.: Le Bbar de greg :. \r ------------------ \r \(nachosAmount)x Nachos \((String(format:"%.2f",nachosPrice))) €   |  Total : \((String(format:"%.2f",costNachos))) € \r \(beerAmount)x Bières \((String(format:"%.2f",beerPrice))) €   | Total : \((String(format:"%.2f",costBeer))) € \r Total \((String(format:"%.2f",totalBeerNachos))) €

""")
