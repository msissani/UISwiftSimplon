import UIKit

let temperature = -90

switch temperature {
case Int.min..<65 :
    print("temperature is too cold")
case 65...76 :
    print("temperature is just right")
default:
    print("temperature is hot")

}

print(Int.min, Int.max)
