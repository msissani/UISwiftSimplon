/*:
 ## Exercise - For-In Loops
 
Créez une boucle for-in qui parcourt les valeurs 1 à 100 et affiche chacune de ces valeurs.
 */
for number in 1...100 {
    print(number)
}
/*:
Créez un dictionnaire [String : String] où les clés sont les noms des pays et les valeurs sont leurs capitales. Inclure au moins trois paires de clés/valeurs dans votre collection, puis utiliser une boucle for pour détailler les paires et imprimer les clés et les valeurs dans une phrase.
 ex: La capitale de la France est Paris
 */
var capitales: [String:String] = ["France": "Paris", "Italie":"Rome", "Allemagne":"Berlin"]

for (pays,capitale) in capitales {
    print("La capitale de la \(pays) est \(capitale)")
}


for capitales in capitales {
    print("SECONDE METHODE : La capitale de la \(capitales.key) est \(capitales.value)")
}
//: page 1 of 6  |  [Next: App Exercise - Movements](@next)
