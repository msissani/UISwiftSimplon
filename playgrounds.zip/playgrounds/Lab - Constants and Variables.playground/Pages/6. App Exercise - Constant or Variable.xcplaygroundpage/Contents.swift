/*:
 ## App Exercise - Fitness Tracker: Constante ou Variable?
 
 >Ces exercices renforcent les concepts Swift dans le contexte d'une application de suivi de la condition physique.
   
 
   Une application de suivi de la condition physique doit tenir compte de toutes sortes de choses pour afficher les bonnes informations à l'utilisateur. Comme pour le dernier exercice, déclarez une constante ou une variable pour chacun des éléments suivants et attribuez-leur une valeur raisonnable. Veillez à utiliser les conventions de dénomination appropriées.
   
 
   - Nom: le nom de l'utilisateur
 
 
   - Age: l'âge de l'utilisateur
 
 
   - Nombre de pas effectués aujourd'hui: nombre de pas effectués par un utilisateur aujourd'hui
 
 
   - Nombre d'étapes de l'objectif: objectif de l'utilisateur quant au nombre d'étapes à effectuer chaque jour
 
 
   - Fréquence cardiaque moyenne: fréquence cardiaque moyenne de l'utilisateur au cours des dernières 24 heures
 
 */

let Name: String = "Toto"
var Age: Int = 22
var steps: Int = 20000
let steps_objective: Int = 30000
var freq_heart: Int = 190




/*:
Maintenant, revenez en arrière et ajoutez une ligne après chaque déclaration de constante ou de variable. Sur ces lignes, imprimez une déclaration expliquant pourquoi vous avez choisi de déclarer l’information comme constante ou variable.
 */
//: [Previous](@previous)  |  page 6 of 10  |  [Next: Exercise - Types and Type Safety](@next)
