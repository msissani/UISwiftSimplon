/*:
 ## Exercise - Variables
 Déclarez une variable `schooling` et réglez-la sur le nombre d'années d'études que vous avez terminées. Imprimez `schooling` sur la console.
 */
var schooling = 5
/*:
Maintenant, imaginez que vous veniez de terminer une année scolaire supplémentaire et mettez à jour la variable `schooling` en conséquence. Imprimez `schooling` sur la console.
 */
print(schooling+1)

/*:
Le code ci-dessus est-il compilé? Pourquoi est-ce différent d'essayer de mettre à jour une constante? Imprimez votre explication sur la console en utilisant la fonction `print`.
 */
print("parceque c'est une variable")

//: [Previous](@previous)  |  page 3 of 10  |  [Next: App Exercise - Step Count](@next)
