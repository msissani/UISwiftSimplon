/*:
 ## Exercise - Logical Operators

 Pour chaque expression logique ci-dessous, utiliser print pour afficher ce que vous pensez que le résultat sera (true ou false). Puis, print l'expression pour savoir si vous aviez raison. Un exemple est donné juste en dessous.
 
    43 == 53
    print(false)
    print(43 == 53)

 
 1. `9 == 9`
 */
print(9 == 9)
/*:
 2. `9 != 9`
 */
print(9 != 9)
/*: 
 3. `47 > 90`
 */
print(47 > 90)
/*:
 4. `47 < 90`
 */

print(47 < 90)
/*:
 5. `4 <= 4`
 */
print(4 <= 4)
/*:
 6. `4 >= 5`
 */
print(4 >=  5)
/*:
 7. `(47 > 90) && (47 < 90)`
 */
print((47 > 90) && (47 < 90) )
/*:
 9. `!true`
 */
print(!true)
//: page 1 of 9  |  [Next: Exercise - If and If-Else Statements](@next)
