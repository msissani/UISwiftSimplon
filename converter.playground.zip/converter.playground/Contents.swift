import UIKit

var str = "Hello, playground"

func celsiusFrom(kelvin: Double) {
    print(kelvin-273.15)
}

func farhenheitFrom(_ celsius: Double) -> Double {
    return (celsius*9/5)+32
}


celsiusFrom(kelvin: 0)

var celsius2fahrenheit = farhenheitFrom(100)
print(celsius2fahrenheit)
